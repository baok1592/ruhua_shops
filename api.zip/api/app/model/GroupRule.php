<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/12/26 0026
 * Time: 11:48
 */

namespace app\model;


use bases\BaseModel;

class GroupRule extends BaseModel
{

}