<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/10/15 0015
 * Time: 14:28
 */

namespace app\model;


use bases\BaseModel;

class Image extends BaseModel
{
}