<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/12/31 0031
 * Time: 10:15
 */

namespace app\model;

use bases\BaseModel;

class PlayAward extends BaseModel
{

}