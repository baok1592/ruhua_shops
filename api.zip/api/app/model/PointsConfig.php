<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/10/29 0029
 * Time: 15:33
 */

namespace app\model;


use bases\BaseModel;

class PointsConfig extends BaseModel
{

}