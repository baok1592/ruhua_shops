<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/10/21 0021
 * Time: 14:10
 */

namespace app\model;


use bases\BaseModel;

class Tui extends BaseModel
{

}