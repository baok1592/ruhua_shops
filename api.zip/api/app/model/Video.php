<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/12/31 0031
 * Time: 11:14
 */

namespace app\model;


use bases\BaseModel;

class Video extends BaseModel
{

}