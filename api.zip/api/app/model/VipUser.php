<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/1/9 0009
 * Time: 13:40
 */

namespace app\model;


use bases\BaseModel;

class VipUser extends BaseModel
{

}