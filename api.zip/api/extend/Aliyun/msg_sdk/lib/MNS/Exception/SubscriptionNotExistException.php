<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class SubscriptionNotExistException extends MnsException
{
}
?>
