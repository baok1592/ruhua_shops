const Api_url='/../'      

// const Api_url='http://192.168.1.107:8012/'
export {Api_url}