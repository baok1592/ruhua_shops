<template>
	<view class="discount">
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">
.discount{
	
}
</style>
